args = commandArgs(trailingOnly = TRUE) ## order aalpha, S, sigmaNoise, sigma_0

rowID <- args[1]
aarg <- as.numeric(rowID)

setwd("/ufrc/phc6068/share/zhuo/testR")
mycars <- mtcars[aarg,]
filename <- paste0("arg",aarg,".csv")
write.csv(mycars,filename)


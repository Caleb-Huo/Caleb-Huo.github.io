setwd("/ufrc/phc6068/share/zhuo/testR")
mycars <- mtcars
write.csv(mycars,"mycars.csv")

